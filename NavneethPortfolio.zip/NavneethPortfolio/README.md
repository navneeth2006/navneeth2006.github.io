# Navneeth Dev J — Portfolio

React + Vite portfolio site. Replace `/src/assets/profile.jpg` with your profile photo and update project repo links in `src/App.jsx`.

## Quick start
1. `npm install`
2. `npm run dev`
3. Build: `npm run build`

Deploy to Vercel or Netlify, or configure GitHub Pages (publish `dist/`). For GitHub Pages automated deployment, a GitHub Actions workflow is included.
